<script>



var stopTimerHeaderSignIn = setInterval(function(){
$(document).click(function (e)
{
    var container = $(".toolltip"); 

    if (!container.is(e.target) && container.has(e.target).length === 0)
    {
        //debugger;
        container.fadeOut();
    }
});

if ( $('button.enterprise-account__button.enterprise-account__button_sign-in').length > 0 ){
//console.log("header has loaded");
//setTimeout(function(){ 

var placeHolder = $('button.enterprise-account__button.enterprise-account__button_sign-in');
var signInTag = $('<div class="toolltip"><a href="https://www.canadiantire.ca/en/signin-registration.html"> Sign In</a><div><span>New Customer?</span> <a href="https://www.canadiantire.ca/en/full-registration.html#create"> Sign Up</a></div></div>');

switch($("button.enterprise-account__button.enterprise-account__button_sign-in").length ) {
case 1:
  if ( $('.toolltip').length < 1 ) {
  $(signInTag).appendTo(placeHolder);
  //debugger;
  }

  function getCookie(cname,cvalue) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

var checkValue = (getCookie('signin_username') != 'SignedIn');
//debugger;
if ( $(".initial-global-store").children().length < 1 ) {
  //debugger;
//console.log("value");
switch(checkValue) {
    case true:
    //debugger;
      //console.log("true");
        $(".toolltip").css("visibility","visible");
        document.cookie = "signin_username=SignedIn";
        break;
    case false:
    //debugger;
        //console.log("false");
        $(".toolltip").css("visibility","hidden");
        break;
}

var start = new Date().getTime();
elapsed = '0.0';
//debugger;

var x = setInterval(function(){
  //console.log(elapsed);
                
                   if ( elapsed > 1 && $(placeHolder).find(signInTag).length > 0 ) {
                    $(".toolltip").fadeOut();
                    clearInterval(x);
                   }
              var time = new Date().getTime() - start;
              elapsed = Math.floor(time / 1000) / 10;
              //debugger;
          }, 1000);
}
break;
}
//}, 4000);
clearInterval(stopTimerHeaderSignIn);
}
}, 1000);


</script>

<style>
 
  .toolltip {
  
  visibility: hidden;
    width: 194px;
    background-color: #fff;
    color: #000;
    text-align: center;
    border-radius: 6px;
    padding: 15px 0;
    position: absolute;
    top: 42px;
    margin-left: -72px;
    z-index: 4;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    -webkit-box-shadow:0px 4px 48px -11px rgba(0,0,0,0.18);
    -moz-box-shadow: 0px 4px 48px -11px rgba(0,0,0,0.18);
    box-shadow: 0px 4px 48px -11px rgba(0,0,0,0.18);
    border: 1px solid #c4bdbd;
}

.toolltip:after {
  
        content: '';
    position: absolute;
    top: -7px;
    height: 12px;
    width: 12px;
    background-color: #fff;
    border-left: 1px solid #c4bdbd;
    border-top: 1px solid #c4bdbd;
    transform: rotate(45deg);
    left: 47%;
}

.toolltip > a {
  
  background: #15782f;
    padding: 5px 45px;
    border-radius: 6px;
    color: #fff;

}
.toolltip > div {
  
      margin-top: 13px;
}
.toolltip > div  a {
  
  font-size: 16px;
    font-weight: 600;
    color: #000;
    text-decoration: underline;

}
</style>