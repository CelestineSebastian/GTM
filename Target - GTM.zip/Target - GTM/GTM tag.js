
<script>
try {
	
	$('body').append('<style></style>');

}
catch(e){
	
	console.log("Something is missing "+e);
}
</script>