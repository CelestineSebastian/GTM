<script>
count=0;
var tt = setInterval(function(){


CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SHOW_SKU_NUMBER,function(){
for(cartIndex in window.CTC.GTM.mediator["_history"]["show-sku-number"])
    {
      var cart = window.CTC.GTM.mediator["_history"]["show-sku-number"][cartIndex];    
      onlineSku = cart["isOnlineOnly"];
    } 

//debugger;
if ( onlineSku == true && $(".out-of-stock__similar-products .recently-viewed-product-tiles__list.recently-viewed-carousel").children().length > 0 ) {
//debugger;
      $(".out-of-stock__similar-products").addClass("hide");
      clearInterval(tt); 
}

else if (onlineSku === undefined || count > 40 ) {
//debugger;
clearInterval(tt); 
//console.log("clear tt");
}

count ++;

    });

}, 500);
</script>