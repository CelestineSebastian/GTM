<script>
var timesRun = 0;
var interval = setInterval(function(){
timesRun += 1;
    if(timesRun < 30){

			/* To move Save Badge */

				if ( $(".product-header-badges.section .price__tag.price__tag_save-story").text().length && $(".pdp-buy-box .product-header-badges.section").length < 1 ){
							$(".product-header-badges.section").prependTo(".pdp-buy-box"); 
					}

			/* End of the Save Badge */

		var badgeLength = $(".pdp-product-image__tested-badge").length;
		var bestSellerLength = $(".best-seller").text().length;
		var pdpHeaderSection = $(".pdp-header.pdp-header-section");
				if ( badgeLength >= 1  ) {
					//$(".pdp-product-image__badge-wrapper").remove();
                      $(".pdp-product-image__tested-badge.pdp-product-image__tested-badge-en").remove();
    					if ( $(".badgewrapper").length ){
								$("<img src='https://canadiantire.scene7.com/is/image/CanadianTire/testedctirebadge2?wid=118&hei=60&fmt=png-alpha' style=width:10%;>").appendTo(".badgewrapper");
     					}
     					else {

							$('<div class="badgewrapper"><img 	src="https://canadiantire.scene7.com/is/image/CanadianTire/testedctirebadge2?wid=118&hei=60&fmt=png-alpha" style=width:10%;></div>').prependTo(pdpHeaderSection);
							}
					
					clearInterval(interval);
				}   
	}
	else if  ( timesRun > 30 ) {
		clearInterval(interval);
	}
    
}, 250); 
</script>

<style>

  .badgewrapper {

top: 6px;
    position: relative;	
    margin-bottom:10px;
}
h1.pdp-header__product-name{
      margin-bottom: 5px;
  }
  
  h4.stock-status__product-number{
      margin-top: -3px;
  }
  
  .badgewrapper > img {

 
  margin-right: 10px;
    

  }
.badgewrapper > img:nth-child(2),.badgewrapper > img:nth-child(3){
    
  margin-right: 10px;
  order:3;
    
}

.badgewrapper {

display: flex;
align-items: center;
}
  
  @media only screen and (max-width:800px){
	.badgewrapper  img{
	width:7.7% !important;
	}
}


@media only screen and (max-width:600px){
	.badgewrapper  img{
	width:14.7% !important;
	}
}

</style>