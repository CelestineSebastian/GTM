<script>
  

  function testedMain(){
       count=0;
      var clear = setInterval(function(){

  if ( count < 60 ) {

/* for all SRP */
  $(".search-results-grid__content .temporary-grid-item").each(function(){

     if($(this).find(".tested-badge__image").length) {

      $(this).find(".tested-badge__image img").prop("src","https://canadiantire.scene7.com/is/image/CanadianTire/tested_fr_web@2x?wid=118&hei=59&fmt=png-alpha");
      $(this).find(".tested-badge__image img").prop("srcset","https://canadiantire.scene7.com/is/image/CanadianTire/tested_fr_web@2x?wid=118&hei=59&fmt=png-alpha");   

    }
  });

  /* End of SRP */

  /* auto srp */
   
   if ($(".srp-grid__content .srp-grid__item").length > 0 ) {
       $(".srp-grid__content .srp-grid__item").find(".tested-badge__image img").prop("src","https://canadiantire.scene7.com/is/image/CanadianTire/tested_fr_web@2x?wid=118&hei=59&fmt=png-alpha");  
       $(".srp-grid__content .srp-grid__item").find(".tested-badge__image img").prop("srcset","https://canadiantire.scene7.com/is/image/CanadianTire/tested_fr_web@2x?wid=118&hei=59&fmt=png-alpha"); 
      }
/* End of auto srp */

/* carousel */
      if ($(".recently-viewed-product-tiles__list .item").length > 0 ) {
        $(".recently-viewed-product-tiles__list .item").find(".flyer-badge img").prop("src","https://canadiantire.scene7.com/is/image/CanadianTire/tested_fr_web@2x?wid=118&hei=59&fmt=png-alpha");  
      }
/* End of carousel */
  count++;
  }

else {

  clearInterval(clear);

}
}, 800);
}

 
testedMain();

$("a.srp-grid__load-more-link,button.owl-next,button.owl-prev,label.srp-sidebar__filter-label").click(function(){
testedMain();
});

CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SNP_DATA_LOADED,function(){
testedMain();
});
  
  
</script>