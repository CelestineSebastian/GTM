<style>
.delivery-option__item-title--up::after {
    content: none;
}
  .delivery-option__item-title.delivery-option__item-title--down::after{content:none;}  
 
</style>

<script>
$(document).ready(function(){
  CTC.getService("core.communication.mediator").subscribe(CTC.EVENTS.SHOPPING_CART_ITEM_RENDERED, function(){
var x = $('.delivery-option__item.delivery-option__item--installation.collapse');
if(x.length > 0) {
  $(x).each(function(){ 
    $(this).addClass("in");
  });
  };
});
});
</script>