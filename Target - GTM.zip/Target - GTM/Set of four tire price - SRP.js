<script>
$(document).ready(function(){
CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SNP_DATA_RENDERED,function(){
function tnlFourPrice(){
$(".srp-grid__item").each(function(e){
var clearanceBadge = $(this).find("span.auto-product-badges__item.auto-product-badges__item_clearance.clearance__block").length;
var setOfFourPriceTag = $(this).find(".automotive-product-tile-srp__product-data section.automotive-price.automotive-price_clearance.automotive-price_set-of-sku-part span.automotive-price__current-price .automotive-price__value");
var setOfFourPrice = $(setOfFourPriceTag).text().split("$");
var setofFourPriceMobileTag = $(this).find(".automotive-product-tile-srp__set-of-4-mobile section.automotive-price.automotive-price_clearance.automotive-price_set-of-sku-part span.automotive-price__current-price .automotive-price__value");
var setofFourPriceMobile = $(setofFourPriceMobileTag).text().split("$");
var singlePrice    = $(this).find(".automotive-product-tile-srp__price-with-set-of-4 section.automotive-price.automotive-price_clearance.automotive-price_set-of-sku-part span.automotive-price__current-price  .automotive-price__value").text().split("$");
var newSetOfFourPrice,decimalValue,newValue,digits;

 if ( clearanceBadge ) {
   if ( ( setOfFourPrice[1] = singlePrice[1] ) || ( setofFourPriceMobile[1] = singlePrice[1]) ) {
       
        newSetOfFourPrice = 4*setOfFourPrice[1];
        newValue          = newSetOfFourPrice.toString();

          function splitThreeDigit(){
              digits       = newValue.split(".");
              digits[0]    = digits[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
              final_digits = digits.join(".");
              return final_digits;
          }

        if (newValue.indexOf('.') !== -1 ) {
            splitThreeDigit();
            $(this).find(".automotive-product-tile-srp__set-of-4 .automotive-price__value").html('<span class="newPrice">$'+ "" +final_digits+'</span>');  
        }
        else {
            splitThreeDigit();
            $(this).find(".automotive-product-tile-srp__set-of-4 .automotive-price__value").html('<span class="newPrice">$'+ "" +final_digits+'.00</span>');
        } 
       }
 
 }
});

}

tnlFourPrice();
setTimeout(function(){
tnlFourPrice();
}, 3000);
});
});
</script>
<style>

.automotive-price__fees {

    display:flex;
}
</style>