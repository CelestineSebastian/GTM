<style>
  
  .base-page-body,.shopping-cart-main,.column__a27b6ce2 .column-control-background,.checkout-header,.column__dbbf0dac .column-control-background,.parsys.content-paragraph .column-control-background{
	
	background:#fff !important;
}
  
  
</style>