<script>
  function searchVerbiage($){
var searchVerbiagee = setInterval(function(){



if ( ($('button.enterprise-account__button.enterprise-account__button_sign-in').length > 0 ) && ( ($("input#global-atlas-search__input").attr("placeholder") == "What are you looking for today?") == true ) )  {


        
        $("input#global-atlas-search__input").attr("placeholder","I’m looking for…");
                 
clearInterval(searchVerbiagee);
}
}, 1000);
}




var waitForjQuery = setInterval(function() {
  if (window.jQuery) {
    clearInterval(waitForjQuery);
    searchVerbiage(jQuery);
  }
}, 50);
  
</script>