<script>
  
var clear = setInterval(function(){

if ( $(".product-header-badges.section .price__tag.price__tag_save-story").text().length && $(".pdp-buy-box .product-header-badges.section").length < 1 ){
$(".product-header-badges.section").prependTo(".pdp-buy-box"); 
clearInterval(clear);
}



}, 250);
  
  
</script>

<style>

  h1.pdp-header__product-name{
      margin-bottom: 5px;
  }
  
  h4.stock-status__product-number{
      margin-top: -3px;
  }
 
  
  
</style>