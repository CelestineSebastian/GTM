<script>

  CTC.getService('core.communication.mediator').subscribe(CTC.EVENTS.SNP_DATA_RENDERED,function(){

 $(".search-results-grid__content .temporary-grid-item").each(function(){


                var limitedBadge = $('<div class="one">' + "LIMITED TIME " +'<span>'+"OFFER"+ '</span></div>');

              
                var price=$(this).find(".price__tag").text();

                /* new code */
                  var badgeTagLength = $(this).find(".flex-container-badges").length;
                  var addBadgeTag = $('<div class="flex-container-badges"></div>');
                  if ( badgeTagLength < 1 ) {

                    var place = $(this).find(".product-tile-srp__middle-content");
                      $(addBadgeTag).insertBefore(place);

                          }

                  
                /* End of new code */
  var x =$(this).find(".one").length;
                if(price!=0 && x < 1){
              
if ( $(this).find(".best-seller").length || $(this).find(".newproduct").length ) {

  
  $(this).find(".newproduct").addClass("mobileNone");
  $(this).find(".best-seller").addClass("mobileNone");
}
              //$(this).find(".product-tile-srp__title-and-rate-wrapper").addClass("specialCss");
$(".price__total.price__total--tile").addClass("specialCss");
$(".product-tile__price-wrapper .price__tags.price__tags--tile").addClass("specialCss");
$(".product-tile-srp__details .product-tile__price-wrapper").addClass("specialCss");
$(".grid--grid-view .product-tile-srp__title-and-rate-wrapper").addClass("specialCss");
$("h3.product-tile-srp__title.grid--grid-view__item").addClass("specialCss");


/* this is the code to check if other tags are exists */

if ( badgeTagLength >= 1) {

var limitedBadgePlace = $(this).find(".flex-container-badges");
$(limitedBadge).appendTo(limitedBadgePlace);

if ( $(this).find(".flex-online-badges").length || $(this).find(".flex-instore-badges").length ) {
	
	$(this).find(".flex-container-badges").addClass("displayNone");
}

}
else  {
var place = $(this).find(".product-tile-srp__middle-content");
$(addBadgeTag).insertBefore(place);

var limitedBadgePlace = $(this).find(".flex-container-badges");
$(limitedBadge).appendTo(limitedBadgePlace);

if ( $(this).find(".flex-online-badges").length || $(this).find(".flex-instore-badges").length ) {
	
	$(this).find(".flex-container-badges").addClass("displayNone");
}

}
/*
if ( ($(this).find(".quantity-test").length ) ){
$(this).find(".product-tile-srp .product-tile-srp__title").css("margin-bottom","0");
$(this).find(".product-tile-srp__title-and-rate-wrapper").css({"top": "17px", "height": "75px"});
$(this).find("p.product-tile-srp__product-id").css({"top": "17px", "position": "relative"});
}
*/
/* End of the checking code */


  
                
                }

 });


});


  
</script>

<style>
  
  .displayNone {

    display:none !important;
}


  .flex-container-badges {
bottom: 3px;
position:relative;
display:flex;
align-items:center;

}


  .one {
  
    border: 1px solid #000;
    padding: 2px 5px;
    margin-left:5px;
    border-radius: 12px;
    color: #000;
    font-size: 10px;
    font-weight: 800;
}

.one:first-child {

  margin-left:0;
}
  

.flex-container-badges {
    height: 20.66667px;
}
.mobileNone {

  display:none !important;
}
@media only screen and (max-width:600px){
.one {
   
    font-size: 10px;
   
   
}

  
}
  
</style>