<script>

const productCarousel = () => {

for(isOnlin in window.CTC.GTM.mediator["_history"]["pdp-current-price-notification"]) {
 isonline = window.CTC.GTM.mediator["_history"]["pdp-current-price-notification"][isOnlin]; 
   var quantity = isonline["Quantity"];

 	for(prodIndex in isonline["IsOnline"]) { 

 
          var orderable  = isonline["IsOnline"]["Orderable"];
          var sellable  = isonline["IsOnline"]["Sellable"];

    if ( ( quantity == 0 ) && ( orderable == "Y" ) && ( sellable == "Y" ) ) {

       if ( $(".out-of-stock__similar-products .recently-viewed-product-tiles__list.recently-viewed-carousel").children().length > 0 ) {

       $(".out-of-stock__similar-products").addClass("hideCarousel");
        
        clearInterval(stopCarousel);
           }
       
    }
   
     else  {
     
        clearInterval(stopCarousel);
     }
   

 }

}

};
var stopCarousel;
function timerCall(){
count=0;
stopCarousel = setInterval(function(){

if ( count < 10 ) {

count ++;
}

else  {

  //console.log("functioncalled");
  productCarousel();
$(document).on("change","select#selectSku,select#Colour,select#Size",function(){

//console.log("change applied");
timeOut();

});

}

}, 500);
}

timerCall();


function timeOut() {
  setTimeout(function(){

    productCarousel();
  }, 4000);
}



</script>

<style>

.hideCarousel {

	display:none !important;
}

</style>